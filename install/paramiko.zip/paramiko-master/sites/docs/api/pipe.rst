Cross-platform pipe implementations
===================================

.. automodule:: paramiko.pipe
